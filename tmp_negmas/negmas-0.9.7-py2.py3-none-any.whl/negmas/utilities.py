from negmas import warnings

warnings.deprecated(f"Module `utilities` is depricated. Use `preferences` instead")

from .preferences import *
