#!/usr/bin/env python
"""
Generic methoods for iterating over mappings
"""
from __future__ import annotations

__all__ = []
