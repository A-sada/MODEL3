# -*- coding: utf-8 -*-
"""Implements Concurrent Negotiation Mechanisms and their agents"""

from __future__ import annotations

from .chain import *

__all__ = chain.__all__
