__all__ = ["NegMASException"]


class NegMASException(Exception):
    ...
