"""
Opponent's UFun modeling.
"""
from __future__ import annotations

__all__ = []
