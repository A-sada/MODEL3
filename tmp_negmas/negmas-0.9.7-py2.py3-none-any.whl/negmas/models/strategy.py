"""
Opponent Strategy modeling.
"""
from __future__ import annotations

__all__ = []
