# -*- coding: utf-8 -*-
"""A package for generalized opponent modeling"""
