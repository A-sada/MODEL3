from __future__ import annotations

import pytest

if __name__ == "__main__":
    pytest.main(args=[__file__])
