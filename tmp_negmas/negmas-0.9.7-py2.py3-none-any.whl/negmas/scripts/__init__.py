# -*- coding: utf-8 -*-
"""Command line scripts"""
from __future__ import annotations
